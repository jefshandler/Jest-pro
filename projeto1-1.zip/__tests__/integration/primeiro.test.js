describe("Somar 2", () => {
    it('should sum', () => {
        const x = 2;
        const y = 5;

        const sum = x + y;

        expect(sum).toBe(7);

    });
})